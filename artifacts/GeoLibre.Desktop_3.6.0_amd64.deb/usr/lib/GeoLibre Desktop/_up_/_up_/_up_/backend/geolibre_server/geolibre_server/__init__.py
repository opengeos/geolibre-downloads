"""GeoLibre Python processing sidecar."""
